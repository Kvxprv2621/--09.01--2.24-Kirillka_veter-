<?php
$company = "TaskFlow";
$slogan = "Все ваши заявки — в одном месте";
$currentDate = date("d.m.Y");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($company) ?> — Портал заявок</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/main.js" defer></script>
</head>
<body>
    <header class="header">
        <a class="logo" href="index.php">
            <span class="logo-icon">T</span>
            <span>Task<span class="logo-accent">Flow</span></span>
        </a>
        <span class="header-label">Портал заявок</span>
    </header>

    <main class="hero">
        <div class="hero-title">
            <h1>Решайте задачи.<br><span>Достигайте большего.</span></h1>

            <div class="actions">
                <a class="button button-primary" href="login.php">
                    Войти
                </a>
                <a class="button button-secondary" href="register.php">
                    Регистрация
                </a>
            </div>
        </div>

        <div class="hero-content">
            <p class="description">
                <?= htmlspecialchars($slogan) ?>.
                Создавайте обращения, следите за их статусом
                и работайте эффективнее вместе с командой.
            </p>

            <ul class="features">
                <li class="feature">Удобное управление</li>
                <li class="feature">Контроль заявок</li>
                <li class="feature">Экономия времени</li>
            </ul>
        </div>
    </main>

    <footer class="footer">
        <div class="footer-inner">
            <span>© <?= date("Y") ?> <?= htmlspecialchars($company) ?></span>
            <span>Сегодня: <?= $currentDate ?></span>
        </div>
    </footer>
</body>
</html>