
console.log('Портал загружен');

document.addEventListener('DOMContentLoaded', () => {
    console.log('HTML-страница готова к работе');
});
